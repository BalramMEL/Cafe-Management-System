package com.cafe.domain;

public enum RoleName {
    Admin,
    Cafe,
    Customer
}
